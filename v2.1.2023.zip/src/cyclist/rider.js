class Rider{
  constructor(){
    
  }
}
