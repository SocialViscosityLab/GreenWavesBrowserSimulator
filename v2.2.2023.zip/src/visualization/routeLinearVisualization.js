/**
 * Needs the route to get the length and all its segments
 * Needs a plotting origin
 * Needs a canvas width and height
 * Needs a padding (could be part of the plotting origin)
 * Needs a 
 */

class VisualLinearRoute {
    constructor(route, width, height, origin) {
        this.route = route;
        this.width = width;
        this.height = height;
        this.origin;
        origin;
    }

}