Instructions to build the documentation here:
https://github.com/documentationjs/documentation/blob/master/docs/GETTING_STARTED.md

Once installed run this script:
documentation build src/** -f html -o docs
