class Bicycle{
  constructor(){
    
  }
}
